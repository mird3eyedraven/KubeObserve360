
import React from 'react'
import ReactDOM from 'react-dom/client'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <h1>Hello from KubeObserve360 Frontend</h1>
  </React.StrictMode>
)
