#!/bin/bash
# Script to bootstrap local dev environment (Minikube or KinD)
